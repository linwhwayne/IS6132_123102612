<?php
session_start();
header("Content-Type: text/html;charset=utf-8");
// Perform operations to add, delete, and modify product information

// 1. Import configuration file and function library file
require("dbconfig.php");
require("functions.php");


// 2. Get the value of the action parameter and perform corresponding operations
switch($_GET["action"]){
    case "add": // Add
        // 1. Get adding information
        $userId         = $_SESSION['userId'];
        $goodsId        = trim($_POST["goods_id"]); // Product id
        $orderSn        = date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT); // Order number
        $consignee      = trim($_POST['consignee']); // Consignee
        $phone          = trim($_POST['phone']); // Contact number
        $address        = trim($_POST['address']); // Shipping address
        $orderMoney     = 0; // Order amount
        // Query order amount
        $sql = "select * from goods where id={$goodsId}";
        $result = mysql_query($sql);
        if($result && mysql_num_rows($result) > 0){
            $goods = mysql_fetch_assoc($result); // Parse out the product information to be modified
            $orderMoney = $goods['price'];
        }else{
            alertMes('Product does not exist', 'index.php');
        }
        if($orderMoney <= 0){
            alertMes('Order amount must be greater than 0', 'index.php');
        }
        
        $createtime     = date('y-m-d H:i:s'); // Order time
        
        // 2. Validation
        if(empty($phone)){
            alertMes('Please fill in your phone number', 'addOrder.php?id='.$goodsId);
        }
        if(empty($consignee)){
            alertMes('Please fill in the consignee', 'addOrder.php?id='.$goodsId);
        }
        if(empty($address)){
            alertMes('Please fill in the address', 'addOrder.php?id='.$goodsId);
        }
        
        
        
        // 3. Assemble SQL statement and execute addition
        $sql = "insert into tb_order(user_id,goods_id,order_sn,order_money,consignee,phone,address,createtime) values('{$userId}','{$goodsId}','{$orderSn}','{$orderMoney}','{$consignee}','{$phone}','{$address}','{$createtime}')";
        //echo $sql;
        mysql_query($sql);
        
        // 4. Determine and output the result
        if(mysql_insert_id() > 0){
            alertMes('Order placed successfully!', 'myOrderList.php');
        }else{
            echo "Order failed!" . mysql_error();
        }
        
        
        break;
    
    case "del": // Delete
        $userId         = $_SESSION['userId'];
        // Get the id number to be deleted and assemble the delete SQL, execute
        $sql = "delete from tb_order where id={$_GET['id']} and user_id={$userId}";
        mysql_query($sql);
        
        // Redirect to the browse page
        header("Location:myOrderList.php");
        break;
        
        
    case "update": // Modify
        // 1. Get the information to be modified
        $id             = trim($_POST['id']);
        $orderMoney     = trim($_POST["order_money"]);
        $consignee      = trim($_POST["consignee"]);
        $address        = trim($_POST["address"]);
        $phone          = trim($_POST["phone"]);
        $updatetime     = date('y-m-d H:i:s');
        // 2. Data validation
        if(empty($orderMoney)){
            alertMes("Order amount must have a value", "editOrder.php?id={$id}");
        }
        
        if(empty($consignee)){
            alertMes("Consignee must have a value", "editOrder.php?id={$id}");
        }
        
        if(empty($address)){
            alertMes("Address must have a value", "editOrder.php?id={$id}");
        }
        
        if(empty($phone)){
            alertMes("Phone number must have a value", "editOrder.php?id={$id}");
        }
        
        
        // 3. Execute modification
        $sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
        //echo $sql;
        mysql_query($sql);
        
        // 6. Determine whether the modification was successful
        if(mysql_affected_rows() > 0){
            alertMes("Modification successful", "myOrderList.php");
        }else{
            //echo "Modification failed".mysql_error();
            alertMes("Modification failed", "myOrderList.php");
        }
        
        break;

}

// 4. Close the database
mysql_close();
