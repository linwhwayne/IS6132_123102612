<!doctype html>
<html>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
        <title>Order Information Management</title>
        <link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
    </head>
    <body>
        
            <h3>Order Information List</h3>
            <div class="admin_search_bar">
                <form action="<?php echo $_SERVER['PHP_SELF'];?>">
                    <ul>
                        <li><label>Product Name</label><input type="text" class="txt" name="keyword" value="<?php if(isset($_GET['keyword'])) echo $_GET['keyword'];?>"></li>
                        <li><button class="op_btn">Search</button></li>
                    </ul>
                </form>
            </div>
            
            <table border="1" width="1300px" class="frm_table">
                <tr>
                    <th>Order Number</th>
                    <th>User</th>
                    <th>Product Name</th>
                    <th>Product Image</th>
                    <th>Order Amount</th>
                    <th>Consignee</th>
                    <th>Delivery Address</th>
                    <th>Order Time</th>
                    <th style="width: 150px;">Actions</th>
                </tr>
                <?php
                
                // Retrieve information from the database and output to the browser table
                // 1. Import configuration file 
                    require("../dbconfig.php");
                    
                    // Current page
                    if(!isset($_GET["page"])){
                        $page=1;
                    }else{
                        $page=$_GET["page"];
                    }
                    
                    // Data starts from which row
                    $temp=($page-1)*$list_num;
                    
                    // Search keyword
                    if(!isset($_GET['keyword'])){
                        $keyword = "";
                    }else{
                        $keyword = trim($_GET['keyword']);
                    }
                    
                
                // 2. Connect to the database, and select the database
                    
                    $sql_count = "SELECT count(*) as total FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
                    if($keyword){
                        $sql_count.= " and c.`name` like '%{$keyword}%'";
                    }
                    $result = mysql_query($sql_count);
                    $res = mysql_fetch_array($result);
                    $num=$res['total'];
                    $p_count=ceil($num/$list_num);                    // Total pages is total count divided by number per page
                
                // 3. Execute order information query
                    $sql = "SELECT a.*,b.username,c.`name` as `goods_name`,c.pic FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
                    if($keyword){
                        $sql .=  " and c.`name` like '%{$keyword}%'";
                    }
                    $sql .= " limit {$temp},{$list_num}";
                    $result = mysql_query($sql);
                    
                    
                    
                // 4. Parse order information (parse result set)
                    while($row = mysql_fetch_assoc($result)){
                        echo "<tr>";
                        echo "<td>{$row['order_sn']}</td>";
                        echo "<td>{$row['username']}</td>";
                        echo "<td>{$row['goods_name']}</td>";
                        echo "<td><img src='../uploads/s_{$row['pic']}'/></td>";
                        echo "<td>{$row['order_money']}</td>";
                        echo "<td>{$row['consignee']}({$row['phone']})</td>";
                        echo "<td>{$row['address']}</td>";
                        echo "<td>".$row['createtime']."</td>";
                        echo "<td> 
                                <a href='orderAction.php?action=del&id={$row['id']}' class='op_btn2'>Ship</a> 
                                <a href='editOrder.php?id={$row['id']}' class='op_btn2'>Edit</a></td>";
                        echo "</tr>";
                    }
                    
                
                
                // 5. Release result set, close the database
        
                
                ?>
            </table>
            <?php 
            // Pagination
            if($num > 0){
                $prev_page=$page-1;                        // Define previous page as this page minus 1
                $next_page=$page+1;                        // Define next page as this page plus 1
                echo "<p align=\"center\"> ";
                if ($page<=1)                                // If the current page is less than or equal to 1 only display
                {
                    echo "First Page | ";
                }
                else                                        // If the current page is greater than 1 show link to the first page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=1&keyword={$keyword}'>First Page</a> | ";
                }
                if ($prev_page<1)                            // If the previous page is less than 1 only display text
                {
                    echo "Previous Page | ";
                }
                else                                        // If greater than 1 show link to the previous page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=$prev_page&keyword={$keyword}'>Previous Page</a> | ";
                }
                if ($next_page>$p_count)                        // If the next page is greater than total pages only display text
                {
                    echo "Next Page | ";
                }
                else                                        // If less than total pages show link to the next page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&keyword={$keyword}' class='underline'>Next Page</a> | ";
                }
                if ($page>=$p_count)                        // If the current page is greater than or equal to total pages only display text
                {
                    echo "Last Page</p>\n";
                }
                else                                        // If current page is less than total pages show link to the last page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=$p_count&keyword={$keyword}'>Last Page</a></p>\n";
                }
            }else{
                echo "<P align='center'>There are no records yet!</p>";
            }
            ?>
    </body>
</html>
