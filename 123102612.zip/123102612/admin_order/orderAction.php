<?php
session_start();
header("Content-Type: text/html;charset=utf-8");
// Perform operations to add, delete, or modify product information

// 1. Import configuration file and function library
require("../dbconfig.php");
require("../functions.php");

// 2. Connect to MySQL and select the database


// 3. Get the value of the action parameter and perform the corresponding operation
switch($_GET["action"]){
    
    case "del": // Delete
        // Get the id to delete and assemble the delete SQL, then execute
        $sql = "delete from tb_order where id={$_GET['id']}";
        mysql_query($sql);
        
        // Redirect to the browsing interface
        header("Location:orderList.php");
        break;
        
        
    case "update": // Update
        // 1. Get the information to be modified
        $id             = trim($_POST['id']);
        $orderMoney     = trim($_POST["order_money"]);
        $consignee      = trim($_POST["consignee"]);
        $address        = trim($_POST["address"]);
        $phone          = trim($_POST["phone"]);
        $updatetime     = date('y-m-d H:i:s');
        // 2. Data validation
        if(empty($orderMoney)){
            die(errorTip("Order amount is required", "editOrder.php?id={$id}"));
        }
        
        if(empty($consignee)){
            die(errorTip("Consignee is required", "editOrder.php?id={$id}"));
        }
        
        if(empty($address)){
            die(errorTip("Address is required", "editOrder.php?id={$id}"));
        }
        
        if(empty($phone)){
            die(errorTip("Phone number is required", "editOrder.php?id={$id}"));
        }
        
        
        // 3. Execute the modification
        $sql = "update tb_order set order_money='{$orderMoney}', consignee='{$consignee}', address='{$address}', phone='{$phone}', updatetime='{$updatetime}' where id={$id}";
        //echo $sql;
        mysql_query($sql);
        
        // 6. Determine if the modification was successful
        if(mysql_affected_rows()>0){
            echo "Update successful";
        }else{
            echo "Update failed".mysql_error();
        }
        echo "<br/> <a href='orderList.php'>Return to list<a>";
        
        break;

}

// 4. Close the database
mysql_close();


