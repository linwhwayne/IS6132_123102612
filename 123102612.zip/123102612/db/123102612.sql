CREATE TABLE `goods` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(500) NOT NULL,
  `typeid` int(10) UNSIGNED NOT NULL,
  `price` double(8,2) UNSIGNED NOT NULL,
  `total` int(10) UNSIGNED NOT NULL,
  `pic` varchar(32) NOT NULL,
  `note` text,
  `addtime` int(10) UNSIGNED NOT NULL,
  `updatetime` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `goods`
--

INSERT INTO `goods` (`id`, `name`, `typeid`, `price`, `total`, `pic`, `note`, `addtime`, `updatetime`) VALUES
(1, 'Fuji Apples', 1, 3.99, 150, '1.jpg', 'Crisp and sweet, perfect for snacking', 1717622400, '2024-05-04 00:00:00'),
(2, 'Cavendish Bananas', 1, 1.29, 200, '2.jpg', 'Rich in potassium and fiber', 1717622520, '2024-05-04 00:02:00'),
(3, 'Valencia Oranges', 1, 4.50, 180, '3.jpg', 'Juicy and rich in vitamin C', 1717622640, '2024-05-04 00:04:00'),
(4, 'Granny Smith Apples', 1, 4.99, 160, '4.jpg', 'Great for pies and fresh salads', 1717622760, '2024-05-04 00:06:00'),
(5, 'Red Seedless Grapes', 1, 2.99, 175, '5.jpg', 'Sweet and vine-grown, seedless', 1717622880, '2024-05-04 00:08:00'),
(6, 'Navel Oranges', 1, 3.50, 190, '6.jpg', 'Seedless and highly nutritious', 1717623000, '2024-05-04 00:10:00'),
(7, 'Bartlett Pears', 1, 3.29, 170, '7.jpg', 'Sweet and ideal for canning', 1717623120, '2024-05-04 00:12:00'),
(8, 'Strawberries', 1, 5.99, 200, '8.jpg', 'Fresh, juicy, and full of vitamins', 1717623240, '2024-05-04 00:14:00'),
(9, 'Blackberries', 1, 6.49, 120, '9.jpg', 'Rich in antioxidants and vitamins', 1717623360, '2024-05-04 00:16:00'),
(10, 'Golden Kiwis', 1, 6.99, 130, '10.jpg', 'Sweet with a tangy flavor, rich in nutrients', 1717623480, '2024-05-04 00:18:00'),
(11, 'Watermelons', 1, 7.99, 80, '11.jpg', 'Large, juicy, and refreshing during summer', 1717623600, '2024-05-04 00:20:00'),
(12, 'Cherries', 1, 9.99, 75, '12.jpg', 'Sweet and deep red, perfect for desserts', 1717623720, '2024-05-04 00:22:00'),
(13, 'Pineapples', 1, 3.99, 90, '13.jpg', 'Tropical flavor, great for juices', 1717623840, '2024-05-04 00:24:00');

-- --------------------------------------------------------

--
-- Table structure for `tb_order`
--

CREATE TABLE `tb_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `goods_id` int(10) DEFAULT NULL,
  `order_sn` varchar(50) DEFAULT NULL COMMENT 'Order Number',
  `order_money` float(10,2) DEFAULT NULL COMMENT 'Order Amount',
  `consignee` varchar(20) DEFAULT NULL COMMENT 'Consignee',
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL COMMENT 'Delivery Address',
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tb_order`
--

INSERT INTO `tb_order` (`id`, `user_id`, `goods_id`, `order_sn`, `order_money`, `consignee`, `phone`, `address`, `createtime`, `updatetime`) VALUES
(8, 1, 1, '2024042428096', 6099.00, '2', '23', '22', '2024-04-24 12:23:34', NULL),
(7, 1, 2, '2024042445862', 5999.00, '2', '2', '2', '2024-04-24 11:53:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `createtime`, `updatetime`) VALUES
(1, 'admin', '96e79218965eb72c92a549dd5a330112', '2024-05-01 10:54:47', NULL),
(2, 'weilai', '96e79218965eb72c92a549dd5a330112', '2024-05-01 11:38:04', NULL),
(3, 'xieweijie', '96e79218965eb72c92a549dd5a330112', '2024-05-02 08:56:00', NULL),
(4, 'xuanyuan', '96e79218965eb72c92a549dd5a330112', '2024-04-28 00:35:18', NULL),
(5, 'daironghao', '96e79218965eb72c92a549dd5a330112', '2024-04-29 10:35:18', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `tb_order`
--
ALTER TABLE `tb_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

