<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>
<body class="shop_body">
    <?php 
        include 'front-top.php'; // Include the top navigation bar
    ?>
    <div class="formContain">
        <form action="registerAction.php?action=add" method="post" onsubmit="return validate_form(this)">
            <h2 class="frm_title">Register</h2>
            <p><span>Enter Username</span><input type="text" name="username" autocomplete="off" class="txt-inp"></p>
            <p><span>Enter Password</span><input type="password" name="password" class="txt-inp"></p>
            <p><span>Confirm Password</span><input type="password" name="repassword" class="txt-inp"></p>
            <p class="txt_center"><input type="submit" value="Register" class="frm-btn" style="border-radius: 5px;"></p>
        </form>
    </div>
    <div class="bottom">
        <p style="text-align: center;height: 100px; line-height: 100px;">
            <a href="index.php" style="color: #fff;">Home</a> <span>|</span> <a style="color: #fff;" href="myOrderList.php">My Orders</a>
        </p>
    </div>
    <script type="text/javascript">
        function validate_form(thisform){
            with (thisform){
                if (validate_required(username,"Please enter username")==false){
                    username.focus();
                    return false;
                }
                if (validate_required(password,"Please enter password")==false){
                    password.focus();
                    return false;
                }
                if (validate_required(repassword,"Please confirm your password")==false){
                    repassword.focus();
                    return false;
                }
                if(validate_equal(password, repassword, "Passwords do not match") == false){
                    repassword.focus();
                    return false;
                }
            }
        }
    </script>
</body>
</html>
