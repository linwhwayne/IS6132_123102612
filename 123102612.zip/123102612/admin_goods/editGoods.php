<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>Product Information Management</title>
		<link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
		<script type="text/javascript" src="../script/check.js"></script>
	</head>
	<body>
			<?php  
				//1. Import configuration file 
					require("../dbconfig.php");
				//2. Connect to the database, and select the database
				
				//3. Retrieve the product information to be modified
					$sql = "select * from goods where id={$_GET['id']}";
					$result = mysql_query($sql);
				
				//4. Check if the product information to be edited is retrieved
					if($result && mysql_num_rows($result)>0){
						$shop = mysql_fetch_assoc($result); // Parse the product information to be modified
					}else{
						die("No product information to modify was found.");
					}
			?>
			<h3 class="page_title">Edit Product Information</h3>
			<form action="goodsAction.php?action=update" enctype="multipart/form-data" method="post" onsubmit="return validate_form(this)">
				<input type="hidden" name="id" value="<?php echo $shop['id']; ?>"/>
				<input type="hidden" name="oldpic" value="<?php echo $shop['pic']; ?>"/>
			<table border="0" width="1200" class="frm_table">
				<tr>
					<td align="right">Name:</td>
					<td><input type="text" name="name" value="<?php echo $shop['name']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Type:</td>
					<td>
						<select name="typeid">
						<?php 
							require("../dbconfig.php");
							foreach($typelist as $k=>$v){
								$sd = ($shop['typeid']==$k)?"selected":""; // Is it the current type?
								echo "<option value='{$k}' {$sd}>{$v}</option>";
							}
						?>
						</select>
					</td>
				</tr>
				<tr>
					<td align="right">Price:</td>
					<td><input type="text" name="price"  value="<?php echo $shop['price']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Stock:</td>
					<td><input type="text" name="total"  value="<?php echo $shop['total']; ?>" class="frm_txt"/></td>
				</tr>
				<tr>
					<td align="right">Picture:</td>
					<td><input type="file" name="pic"/></td>
				</tr>
				<tr>
					<td align="right" valign="top">Description:</td>
					<td><textarea rows="10" cols="70" name="note"><?php echo $shop['note']; ?></textarea></td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<input type="submit" value="Update"/>&nbsp;&nbsp;&nbsp;
						<input type="reset" value="Reset"/>
					</td>
				</tr>
				<tr>
					<td align="right" valign="top">&nbsp;</td>
					<td><img src="../uploads/<?php echo $shop['pic']; ?>" style="max-width: 200px;"/></td>
				</tr>
			</table>
			</form>
		<script type="text/javascript">
		function validate_form(thisform){
			with (thisform){
				if (validate_required(name,"Please enter the product name")==false){
					name.focus();
			      	return false;
			  }
				if (validate_required(price,"Please enter the product price")==false){
					price.focus();
			      	return false;
			  }

				if (validate_required(total,"Please enter the product stock")==false){
					total.focus();
			      	return false;
			  }
				if (validate_required(note,"Please enter the product description")==false){
					note.focus();
			      	return false;
			  }
			}
		}
    </script>
	</body>
</html>
