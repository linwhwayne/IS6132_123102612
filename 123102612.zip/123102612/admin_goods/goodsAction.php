<?php
header("Content-Type: text/html;charset=utf-8");
// Execute operations to add, delete, or update product information

// 1. Import configuration and function library files
require("../dbconfig.php");
require("../functions.php");

// 2. Connect to MySQL and select the database


// 3. Get the value of the action parameter and perform the corresponding operation
switch($_GET["action"]){
    case "add": // Add
        // 1. Get the information to add
        $name   = $_POST["name"];
        $typeid = $_POST["typeid"];
        $price  = $_POST["price"];
        $total  = $_POST["total"];
        $note   = $_POST["note"];
        $addtime = time();
        // 2. Validation
        if(empty($name)){
            die(errorTip("Product name is required", "addGoods.php?id={$id}"));
        }
        // 3. Execute file upload
        $upinfo = uploadFile("pic","../uploads/");
        if($upinfo["error"]===false){
            die(errorTip("Failed to upload image information: ".$upinfo["info"], "addGoods.php?id={$id}"));
        }else{
            // Upload successful
            $pic = $upinfo['info']; // Get the name of the successfully uploaded image
        }
        // 4. Perform image scaling
        imageUpdateSize('../uploads/'.$pic,50,50);
        
        // 5. Assemble SQL statement and execute addition
        $sql = "insert into goods values(null,'{$name}','{$typeid}',{$price},{$total},'{$pic}','{$note}',{$addtime},null)";
        //echo $sql;
        mysql_query($sql);
        
        // 6. Determine and output result
        if(mysql_insert_id()>0){
            echo "Product posted successfully!";
        }else{
            echo "Product posting failed!".mysql_error();
        }
        echo "<br/> <a href='goodsList.php'>Return to product list<a>";
        
        
        break;
    
    case "del": // Delete
        // Get the id to delete and assemble delete SQL, then execute
        $sql = "delete from goods where id={$_GET['id']}";
        mysql_query($sql);
        // Execute image deletion
        if(mysql_affected_rows()>0){
            @unlink("../uploads/".$_GET['picname']);
            @unlink("../uploads/s_".$_GET['picname']);
        }
        // Redirect to the browsing interface
        header("Location:goodsList.php");
        break;
        
        
    case "update": // Update
        // 1. Get the information to update
        $name   = $_POST["name"];
        $typeid = $_POST["typeid"];
        $price  = $_POST["price"];
        $total  = $_POST["total"];
        $note   = $_POST["note"];
        $id = $_POST['id'];
        $pic = $_POST['oldpic'];
        $updatetime     = date('y-m-d H:i:s');
        // 2. Data validation
        if(empty($name)){
            die(errorTip("Product name is required", "editGoods.php?id={$id}"));
        }
        
        // 3. Check if a new picture is uploaded
        if($_FILES['pic']['error']!=4){
            // Perform upload
            $upinfo = uploadFile("pic","../uploads/");
            if($upinfo["error"]===false){
                die(errorTip("Failed to upload image information: ".$upinfo["info"], "editGoods.php?id={$id}"));
            }else{
                // Upload successful
                $pic = $upinfo['info']; // Get the name of the successfully uploaded image
                // 4. If a new picture is uploaded, perform scaling
                imageUpdateSize('../uploads/'.$pic,50,50);
            }
        
        }
        
        // 5. Execute update
        $sql = "update goods set name='{$name}',typeid={$typeid},price={$price},total={$total},note='{$note}',pic='{$pic}',updatetime='{$updatetime}' where id={$id}";
        //echo $sql;
        mysql_query($sql);
        
        // 6. Determine if the update was successful
        if(mysql_affected_rows()>0){
            // If a new picture is uploaded, delete the old picture
            if($_FILES['pic']['error']!=4){
                @unlink("../uploads/".$_POST['oldpic']);
                @unlink("../uploads/s_".$_POST['oldpic']);
            }
            echo "Update successful";
        }else{
            echo "Update failed".mysql_error();
        }
        echo "<br/> <a href='goodsList.php'>Return to product list<a>";
        
        break;

}

// 4. Close the database
mysql_close();


