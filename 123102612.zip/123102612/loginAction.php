<?php
header("Content-Type: text/html;charset=utf-8");
// Perform operations to add, delete, and modify product information
session_start();
// 1. Import configuration file and function library file
require("dbconfig.php");
require("functions.php");


// 2. Get the value of the action parameter and perform corresponding operations

switch($_GET["act"]){
    case "login": // Login
        // 1. Get information
        $username       = trim($_POST["username"]);
        $password       = trim($_POST["password"]);
        $md5Pwd         = md5($password); // Encrypt the password
        $code           = trim($_POST["code"]);
        // 2. Validation
        if(empty($username)){
            alertMes('Username must have a value', 'login.php');
        }
        if(empty($password)){
            alertMes('Password must have a value', 'login.php');
        }
        if(empty($code) || $code != $_SESSION["check_checks"]){
            alertMes('Incorrect verification code', 'login.php');
        }
        
        // Check if the user exists
        $sql_count = "select * from user where username = '{$username}' and password='{$md5Pwd}'";
        $result = mysql_query($sql_count);
        
        
        if($result && mysql_num_rows($result) > 0){
            $item = mysql_fetch_assoc($result);
            if($username == 'admin' || $username == 'weilai' || $username == 'xieweijie' || $username == 'xuanyuan' || $username == 'daironghao'){
                $_SESSION['adminName'] = $item['username'];
                $_SESSION['adminId'] = $item['id'];
                $_SESSION['userName'] = $item['username'];
                $_SESSION['userId'] = $item['id'];
                alertMes('Login successful', 'index.php');
            }else{
                $_SESSION['userName'] = $item['username'];
                $_SESSION['userId'] = $item['id'];
                alertMes('Login successful', 'index.php');
            }
        }else{
            alertMes('Login failed, please login again', 'login.php');
        }

        
        break;
    
    case "logout": // Logout
        // Clear session variables
        $_SESSION['adminName'] = '';
        $_SESSION['adminId'] = '';
        $_SESSION['userName'] = '';
        $_SESSION['userId'] = '';
        
        // Redirect to the browse page
        header("Location:index.php");
        break;
        
        

}

// 4. Close the database
mysql_close();
