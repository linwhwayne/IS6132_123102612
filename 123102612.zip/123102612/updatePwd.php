<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>

<body class="shop_body">
	<?php 
		include 'front-top.php';
		include 'functions.php';
		checkUserLogined();// Check if the user is logged in
	?>
    <div class="formContain">
    	<form action="updatePwdAction.php?action=updatePwd" method="post" onsubmit="return validate_form(this)">
    		<h2 class="frm_title">Change Password</h2>
    		<p><span>Old Password</span><input type="password" name="password" class="txt-inp"></p>
    		<p><span>New Password</span><input type="password" name="newpassword" class="txt-inp"></p>
    		<p><span>Confirm Password</span><input type="password" name="repassword" class="txt-inp"></p>
    		<p class="txt_center"><input type="submit" value="Change" class="frm-btn"></p>
    	</form>
    </div>
	<div class="bottom">
		<p style="text-align: center;height: 100px; line-height: 100px;">
			<a  href="index.php" style="color: #fff;">Home</a> <span>|</span> <a style="color: #fff;" href="myOrderList.php">My Orders </a>
		</p>
	</div>
    <script type="text/javascript">
    function validate_form(thisform){
    	with (thisform){
	      if (validate_required(password,"Please enter your old password")==false){
	    	  	password.focus();
		      	return false;
		  }
	      if (validate_required(newpassword,"Please enter your new password")==false){
	    	  	 newpassword.focus();
	    		 return false;
	     }
	      if (validate_required(repassword,"Please confirm your password")==false){
	    	     repassword.focus();
	    		 return false;
	     }
		     if(validate_equal(newpassword, repassword, "Passwords do not match") == false){
		    	 repassword.focus();
	    		 return false;
			 }
	  }
    }
    </script>
</body>

</html>
