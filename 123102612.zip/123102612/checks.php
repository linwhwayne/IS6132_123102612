<?php
session_start();
header("content-type:image/png");    // Set the format of the generated image to PNG

$image_width = 70;                  // Set the width of the image
$image_height = 18;                 // Set the height of the image
$new_number = '';                   // Initialize the captcha string

// Generate a 4-digit random number
for ($i = 0; $i < 4; $i++) {
    $new_number .= dechex(rand(0, 15));  // Convert decimal numbers to hexadecimal numbers
}

$_SESSION["check_checks"] = $new_number;  // Write the generated random number captcha into the SESSION variable

// Create a canvas
$num_image = imagecreate($image_width, $image_height);
if (!$num_image) {
    die("Unable to create image resource");
}

// Set the background color of the canvas
imagecolorallocate($num_image, 255, 255, 255);

// Loop through the captcha stored in the SESSION variable
for ($i = 0; $i < strlen($_SESSION["check_checks"]); $i++) {
    $font = mt_rand(3, 5);  // Set a random font
    $x = mt_rand(1, 8) + $image_width * $i / 4;  // Set the X coordinate of the random character position
    $y = mt_rand(1, $image_height / 4);  // Set the Y coordinate of the random character position
    $color = imagecolorallocate($num_image, mt_rand(0, 100), mt_rand(0, 150), mt_rand(0, 200));  // Set the color of the character
    imagestring($num_image, $font, $x, $y, $_SESSION["check_checks"][$i], $color);  // Output the character horizontally
}

imagepng($num_image);       // Generate the image in PNG format
imagedestroy($num_image);   // Release the image resource
?>
