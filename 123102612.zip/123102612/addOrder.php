<?php 
require("functions.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Shopping Mall</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
</head>

<body class="shop_body">
    <?php 
        // Include header
        include 'front-top.php';
        // Check if user is logged in
        checkUserLogined();
    ?>
    <div class="goods_detail_contain">
        <?php  
                //1. Import configuration file and connect to database, select database
                    require("dbconfig.php");
                
                //3. Retrieve product information
                    $sql = "select * from goods where id={$_GET['id']}";
                    $result = mysql_query($sql);
                
                //4. Check if product information was retrieved
                    if($result && mysql_num_rows($result)>0){
                        $shop = mysql_fetch_assoc($result);// Parse out product information 
                    }else{
                        alertMes('Product does not exist', 'index.php');
                    }
            
            
            
            ?>
            <h3 class="page_title">Order Information</h3>
            <form  enctype="multipart/form-data" method="post" action="myOrderAction.php?action=add" onsubmit="return validate_form(this)">
                <input type="hidden" name="goods_id" value="<?php echo $shop['id']; ?>"/>
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['userId'];?>">
                <table border="0" style="width:100%;" class="frm_table">
                    <tr>
                        <td align="right" width="60">Name:</td>
                        <td><span  class="frm_txt"><?php echo $shop['name'];?></span></td>
                    </tr>
                    
                    <tr>
                        <td align="right" valign="top">&nbsp;</td>
                        <td><img src="./uploads/<?php echo $shop['pic']; ?>" style="max-width: 200px;"/></td>
                    </tr>
                    
                    <tr>
                        <td align="right">Consignee:</td>
                        <td><input type="text" name="consignee" autocomplete="off"  value="" class="frm_txt"/></td>
                    </tr>
                    <tr>
                        <td align="right">Phone:</td>
                        <td><input type="text" name="phone" autocomplete="off"  value="" class="frm_txt"/></td>
                    </tr>
                    <tr>
                        <td align="right">Address:</td>
                        <td><input type="text" name="address" autocomplete="off"  value="" class="frm_txt"/></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="txt_center"><button class="submit_order_btn">Submit Order</button></td>
                        
                    </tr>
                </table>
            </form>
    </div>
    <div class="bottom">
        <p style="text-align: center;height: 100px; line-height: 100px;">
            <a  href="index.php" style="color: #fff;">Home</a> <span>|</span> <a style="color: #fff;" href="myOrderList.php">My Orders</a>
        </p>
    </div>
    <script type="text/javascript">
        function validate_form(thisform){
            with (thisform){
                if (validate_required(consignee,"Please fill in the consignee")==false){
                    consignee.focus();
                    return false;
              }
                if (validate_required(phone,"Please fill in the phone number")==false){
                    phone.focus();
                    return false;
              }

                if (validate_required(address,"Please fill in the address")==false){
                    address.focus();
                    return false;
              }
            }
        }
    </script>
</body>

</html>
