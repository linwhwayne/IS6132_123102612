<?php 
    session_start();
?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/mystyle.css" type="text/css">
</head>
<div class="shop_header">
        <h1 style="color: #3366FF;"><img src="uploads/shoplogo.png" class="logo"></h1>
        <div class="search_bar" style="margin-top: 15px;">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>">
                <input type="text" name="searchword" autocomplete="off" value="<?php if(isset($_GET['searchword'])) echo $_GET['searchword'];?>">
                <button class="op_btn" style="border-radius: 0;border: 0;height: 36px;">Search</button>
            </form>
        </div>
        <div class="login_register_bar" style="margin-top: 20px;">
            <?php 
                if(isset($_SESSION['userId']) && $_SESSION['userId']){
            ?>
            <?php 
                    if(isset($_SESSION['adminId']) && $_SESSION['adminId']){
            ?>
            
            <a href="admin.php">System Management</a>
            <span>|</span>
            <a href="loginAction.php?act=logout">Logout</a>
            <?php 
                    } else {
            ?>
            <a href="myOrderList.php">My Orders</a>
            <span>|</span>
            <a href="loginAction.php?act=logout">Logout</a>
            <?php 
                    }
            ?>
            <?php 
                
                } else {
            ?>
                <a href="login.php">Login</a>
                <span>|</span>
                <a href="register.php">Register</a>
            <?php 
                }
            ?>
            
            
        </div>
    </div>
    <div class="shop_nav">
        <ul>
            <a href="index.php"><li>Home</li></a>
            <a href="myOrderList.php"><li>My Orders</li></a>
            <?php 
                if(isset($_SESSION['userId']) && $_SESSION['userId']){
            ?>
            <a href="updatePwd.php"><li>Change Password</li></a>
            <?php 
                }
            ?>
        </ul>
    </div>
