<?php
header("Content-Type: text/html;charset=utf-8");
// Perform operations to add, delete, or modify user information

// 1. Import configuration file and function library
require("../dbconfig.php");
require("../functions.php");

// 2. Connect to MySQL and select the database


// 3. Get the 'action' parameter value and perform the corresponding operations
switch($_GET["action"]){
    case "add": // Add
        // 1. Get the information to add
        $username       = trim($_POST["username"]);
        $password       = trim($_POST["password"]);
        $repassword     = trim($_POST["repassword"]);
        $createtime     = date('y-m-d H:i:s');
        $md5Pwd         = md5($password); // Encrypt the password
        // 2. Validation
        if(empty($username)){
            die(errorTip("Username is required", "addUser.php"));
        }
        if(empty($password)){
            die(errorTip("Password is required", "addUser.php"));
        }
        if($password != $repassword){
            die(errorTip("Passwords do not match", "addUser.php"));
        }
        
        // Check if the username already exists
        $sql_count = "SELECT count(*) as total FROM user WHERE username = '{$username}'";
        $result = mysql_query($sql_count);
        if($result){
            $res = mysql_fetch_array($result);
            $num=$res['total'];
            if($num > 0){
                die(errorTip("Username already taken", "addUser.php"));
            }
        }
        
        
        // 3. Assemble SQL statement and execute the addition
        $sql = "INSERT INTO user VALUES(null,'{$username}','{$md5Pwd}','{$createtime}',null)";
        mysql_query($sql);
        
        // 4. Check and output result
        if(mysql_insert_id()>0){
            echo "User added successfully!";
        }else{
            echo "Failed to add user!".mysql_error();
        }
        echo "<br/> <a href='userList.php'>Return to list<a>";
        
        
        break;
    
    case "del": // Delete
        // Get the id to delete and assemble delete SQL, execute
        $sql = "DELETE FROM user WHERE id={$_GET['id']}";
        mysql_query($sql);
        
        // Redirect to browsing interface
        header("Location:userList.php");
        break;
        
        
    case "update": // Update
        // 1. Get the information to modify
        $username       = trim($_POST["username"]);
        $id             = trim($_POST['id']);
        $updatetime     = date('y-m-d H:i:s');
        // 2. Data validation
        if(empty($username)){
            die(errorTip("Username is required", "editUser.php?id={$id}"));
        }
        
        
        // Check if the username is already taken
        $sql_count = "SELECT count(*) as total FROM user WHERE username = '{$username}' AND id !={$id}";
        $result = mysql_query($sql_count);
        if($result){
            $res = mysql_fetch_array($result);
            $num=$res['total'];
            if($num > 0){
                die(errorTip("Username already taken", "editUser.php?id={$id}"));
            }
        }
        
        // 5. Execute the update
        $sql = "UPDATE user SET username='{$username}',updatetime='{$updatetime}' WHERE id={$id}";
        mysql_query($sql);
        
        // 6. Check if the modification was successful
        if(mysql_affected_rows()>0){
            echo "User updated successfully";
        }else{
            echo "Failed to update user".mysql_error();
        }
        echo "<br/> <a href='userList.php'>Return to list<a>";
        
        break;
    case "resetPwd":
        $id             = trim($_POST['id']);
        $updatetime     = date('y-m-d H:i:s');
        $password       = trim($_POST["password"]);
        $repassword     = trim($_POST["repassword"]);
        $createtime     = date('y-m-d H:i:s');
        $md5Pwd         = md5($password); // Encrypt the password
        // 1. Validation
        if(empty($password)){
            die(errorTip("Password is required", "resetUserPwd.php?id={$id}"));
        }
        if($password != $repassword){
            die(errorTip("Passwords do not match", "resetUserPwd.php?id={$id}"));
        }
        // 2. Execute the update
        $sql = "UPDATE user SET password='{$md5Pwd}',updatetime='{$updatetime}' WHERE id={$id}";
        mysql_query($sql);
            
        // 3. Check if the password reset was successful
        if(mysql_affected_rows()>0){
            echo "Password reset successfully";
        }else{
            echo "Password reset failed".mysql_error();
        }
        echo "<br/> <a href='userList.php'>Return to list<a>";
        break;

}

// 4. Close the database
mysql_close();


