<?php 
    // 1. Import configuration file
    require("../dbconfig.php");
    // 2. Connect to the database and select it
    
    // 3. Retrieve the user information to be modified
    $sql = "SELECT * FROM user WHERE id={$_GET['id']}";
    $result = mysql_query($sql);
    
    // 4. Check if the user information to be edited has been retrieved
    if($result && mysql_num_rows($result)>0){
        $item = mysql_fetch_assoc($result); // Parse the information to be modified
    } else {
        die("No information to modify was found.");
    }
?>
<html>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
        <title>User Information Management</title>
        <link rel="stylesheet" href="../css/mystyle.css" type="text/css"/>
        <script type="text/javascript" src="../script/check.js"></script>
    </head>
    <body>
            <h3 class="page_title">Reset User Password</h3>
            <form action="userAction.php?action=resetPwd" enctype="multipart/form-data" method="post" onsubmit="return validate_form(this)">
            <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
            <table border="0" width="900" class="frm_table">
                <tr>
                    <td align="right">Username:</td>
                    <td><input type="text" name="username" class="frm_txt" value="<?php echo $item['username'];?>" disabled="disabled"/></td>
                </tr>
                
                <tr>
                    <td align="right">New Password:</td>
                    <td><input type="password" name="password" class="frm_txt"/></td>
                </tr>
                
                <tr>
                    <td align="right">Confirm Password:</td>
                    <td><input type="password" name="repassword" class="frm_txt"/></td>
                </tr>
                
                <tr>
                    
                    <td colspan="2" align="center">
                        <input type="submit" value="Reset"/>&nbsp;&nbsp;&nbsp;
                    </td>
                </tr>
            </table>
            </form>
    <script type="text/javascript">
        function validate_form(thisform){
            with (thisform){
                if (validate_required(username,"Please enter username")==false){
                    username.focus();
                    return false;
              }
                if (validate_required(password,"Please enter password")==false){
                    password.focus();
                    return false;
              }

                if (validate_required(repassword,"Please confirm password")==false){
                    repassword.focus();
                    return false;
              }
            }
        }
    </script>
    </body>
</html>
