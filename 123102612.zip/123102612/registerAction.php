<?php
header("Content-Type: text/html;charset=utf-8");
// Perform operations of adding, deleting, and modifying product information

// Step 1: Import configuration files and function library files
	require("dbconfig.php");
	require("functions.php");


// Step 2: Get the value of the action parameter and perform the corresponding operation
	switch($_GET["action"]){
		case "add": // Add
			// 1. Get the added information
			$username 		= trim($_POST["username"]);
			$password 		= trim($_POST["password"]);
			$repassword 	= trim($_POST["repassword"]);
			$createtime 	= date('y-m-d H:i:s');
			$md5Pwd 		= md5($password);// Encrypt the password
			// 2. Validation (omitted)
			if(empty($username)){
				alertMes('Username is required', 'register.php');
			}
			if(empty($password)){
				alertMes('Password is required', 'register.php');
			}
			if($password != $repassword){
				alertMes('Passwords do not match', 'register.php');
			}
			
			// Check if the username is duplicate
			$sql_count = "select count(*) as total from user where username = '{$username}'";
			$result = mysql_query($sql_count);
			if($result){
				$res = mysql_fetch_array($result);
				$num=$res['total'];
				if($num > 0){
					alertMes('Username already exists', 'register.php');
				}
			}
			
			
			// 3. Assemble the SQL statement and execute the addition
			$sql = "insert into user(username, password,createtime)  values('{$username}','{$md5Pwd}','{$createtime}')";
			echo $sql;
			mysql_query($sql);
			
			// 4. Check and output the result
			if(mysql_insert_id()>0){
				alertMes('Registration successful', 'login.php');
			}else{
				alertMes('Registration failed!', 'register.php');
			}
			
			
			break;
		
		

	}

// Step 4: Close the database
mysql_close();
