<?php 
// Common function library

/**
  * File upload processing function
  * @param string filename Name of the file form item to upload
  * @param string $path Path where the uploaded file will be saved
  * @param array  Allowed file types
  * @return array Two elements: ["error"] false: failure, true: success
  *               ["info"] Contains the reason for failure or the name of the successfully uploaded file
  */
function uploadFile($filename, $path, $typelist=null){
    //1. Get the name of the uploaded file
    $upfile = $_FILES[$filename];
    if(empty($typelist)){
        $typelist=array("image/gif","image/jpg","image/jpeg","image/png"); // Allowed file types
    }
    $res=array("error"=>false); // Store the result
    //2. Filter upload file error numbers
    if($upfile["error"] > 0){
        switch($upfile["error"]){
            case 1: 
                $res["info"] = "The uploaded file exceeds the upload_max_filesize option limit in php.ini";
                break;
            case 2:
                $res["info"] = "The uploaded file size exceeds the MAX_FILE_SIZE option specified in the HTML form";
                break;
            case 3:
                $res["info"] = "The file was only partially uploaded";
                break;
            case 4:
                $res["info"] = "No file was uploaded";
                break;
            case 6:
                $res["info"] = "Missing a temporary folder.";
                break;
            case 7:
                $res["info"] = "Failed to write file to disk";
                break;
            default:
                $res["info"] = "Unknown error!";
                break;
        }
        return $res;
    }

    //3. Limit the file size for this upload
    if($upfile["size"] > 2000000){
        $res["info"] = "Uploaded file is too large!";
        return $res;
    }

    //4. Filter types
    if(!in_array($upfile["type"], $typelist)){
        $res["info"] = "Upload type does not match! " . $upfile["type"];
        return $res;
    }

    //5. Initialize info (generate a random name for the image)
    $fileinfo = pathinfo($upfile["name"]);
    do{
        $newfile = date("YmdHis") . rand(1000, 9999) . "." . $fileinfo["extension"]; // Randomly generate a file name
    }while(file_exists($newfile));
    //6. Perform the upload
    if(is_uploaded_file($upfile["tmp_name"])){
        if(move_uploaded_file($upfile["tmp_name"], $path . "/" . $newfile)){
            // Assign the successfully uploaded file name to the return array
            $res["info"] = $newfile;
            $res["error"] = true;
            return $res;
        }else{
            $res["info"] = "Failed to upload file!";
        }
    }else{
        $res["info"] = "Not an uploaded file!";
    }
    return $res;
}

//========================================================================================

/**
 * Proportional scaling function (implemented by saving)
 * @param string $picname The source image to be scaled
 * @param int $maxx Maximum width of the scaled image
 * @param int $maxy Maximum height of the scaled image
 * @param string $pre Prefix for the scaled image name
 * @return String Returns the image name with path, e.g., a.jpg => s_a.jpg
 */
function imageUpdateSize($picname, $maxx=100, $maxy=100, $pre="s_"){
    $info = getimageSize($picname); // Get basic information about the image

    $w = $info[0]; // Get width
    $h = $info[1]; // Get height

    // Create an image resource based on the type of image
    switch($info[2]){
        case 1: // gif
            $im = imagecreatefromgif($picname);
            break;
        case 2: // jpg
            $im = imagecreatefromjpeg($picname);
            break;
        case 3: // png
            $im = imagecreatefrompng($picname);
            break;
        default:
            die("Incorrect image type!");
    }

    // Calculate the scaling ratio
    if(($maxx / $w) > ($maxy / $h)){
        $b = $maxy / $h;
    } else {
        $b = $maxx / $w;
    }

    // Calculate the scaled dimensions
    $nw = floor($w * $b);
    $nh = floor($h * $b);

    // Create a new image resource (target image)
    $nim = imagecreatetruecolor($nw, $nh);

    // Perform proportional scaling
    imagecopyresampled($nim, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);

    // Output the image (according to the type of the source image, output as the corresponding type)
    $picinfo = pathinfo($picname); // Parse the source image's name and path information
    $newpicname = $picinfo["dirname"] . "/" . $pre . $picinfo["basename"];
    switch($info[2]){
        case 1:
            imagegif($nim, $newpicname);
            break;
        case 2:
            imagejpeg($nim, $newpicname);
            break;
        case 3:
            imagepng($nim, $newpicname);
            break;
    }
    // Free image resources
    imagedestroy($im);
    imagedestroy($nim);
    // Return result
    return $newpicname;
}

//========================================================================================

/**
 * Adds a logo image watermark to an image (implemented by saving)
 * @param string $picname The source image
 * @param string $logo The watermark image
 * @param string $pre Prefix for the processed image name
 * @return String Returns the image name with path, e.g., a.jpg => n_a.jpg
 */
function imageUpdateLogo($picname, $logo, $pre="n_"){
    $picnameinfo = getimageSize($picname); // Get the basic information of the source image
    $logoinfo = getimageSize($logo); // Get the basic information of the logo image
    // Create an image resource based on the type of the source image
    switch($picnameinfo[2]){
        case 1: // gif
            $im = imagecreatefromgif($picname);
            break;
        case 2: // jpg
            $im = imagecreatefromjpeg($picname);
            break;
        case 3: // png
            $im = imagecreatefrompng($picname);
            break;
        default:
            die("Incorrect image type!");
    }
    // Create an image resource based on the type of the logo image
    switch($logoinfo[2]){
        case 1: // gif
            $logoim = imagecreatefromgif($logo);
            break;
        case 2: // jpg
            $logoim = imagecreatefromjpeg($logo);
            break;
        case 3: // png
            $logoim = imagecreatefrompng($logo);
            break;
        default:
            die("Incorrect logo image type!");
    }

    // Perform the watermark processing
    imagecopyresampled($im, $logoim, $picnameinfo[0] - $logoinfo[0], $picnameinfo[1] - $logoinfo[1], 0, 0, $logoinfo[0], $logoinfo[1], $logoinfo[0], $logoinfo[1]);

    // Output the image (according to the type of the source image, output as the corresponding type)
    $picinfo = pathinfo($picname); // Parse the source image's name and path information
    $newpicname = $picinfo["dirname"] . "/" . $pre . $picinfo["basename"];
    switch($picnameinfo[2]){
        case 1:
            imagegif($im, $newpicname);
            break;
        case 2:
            imagejpeg($im, $newpicname);
            break;
        case 3:
            imagepng($im, $newpicname);
            break;
    }
    // Free image resources
    imagedestroy($im);
    imagedestroy($logoim);
    // Return result
    return $newpicname;
}

/**
 * Error tip
 * @param unknown $msg
 * @param unknown $backUrl
 * @return string
 */
function errorTip($msg, $backUrl){
    return "<div style='text-align:center;margin-top:100px;font-size:18px;'>【{$msg}】" . "<a href='{$backUrl}'>Click to return</a></div>";
}

function  alertMes($mes, $url) {
    echo "<script>alert('{$mes}');</script>";
    echo "<script>window.location='{$url}';</script>";
}

/**
 * Check if the administrator is logged in
 */
function checkLogined() {
    if((!isset($_SESSION['adminId']) || $_SESSION['adminId'] == "")) {
        alertMes("Please login first", "login.php");
    }
}
/**
 * Check if the front-end user is logged in
 */
function checkUserLogined() {
    if((!isset($_SESSION['userId']) || $_SESSION['userId'] == "")) {
        alertMes("Please login first", "login.php");
    }
}
