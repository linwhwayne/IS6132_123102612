<?php
header("Content-Type: text/html;charset=utf-8");
// Perform operations to add, delete, or update product information
session_start();
// Import configuration file and function library file, connect to MySQL, select database
	require("dbconfig.php");
	require("functions.php");

// Get the value of the action parameter and perform the corresponding operation
	switch($_GET["action"]){
		case "updatePwd": // Modify password
			//1. Get information
			$userId			= $_SESSION['userId'];
			$password 		= $_POST['password'];
			$repassword 	= $_POST['repassword'];
			$newpassword 	= $_POST['newpassword'];
			$updatetime 	= date('y-m-d H:i:s');
			
			//2. Validation
			if(empty($password)){
				alertMes('Old password must be provided', 'updatePwd.php');
			}
			if(empty($repassword)){
				alertMes('Confirmation password must be provided', 'updatePwd.php');
			}
			if(empty($newpassword)){
				alertMes('New password must be provided', 'updatePwd.php');
			}
			if($repassword != $newpassword){
				alertMes('Passwords do not match', 'updatePwd.php');
			}
			// Check if the user exists
			$sql_count = "select * from user where id = {$userId}";
			$result = mysql_query($sql_count);
			
			
			if($result && mysql_num_rows($result)>0){
				$item = mysql_fetch_assoc($result);
				if($item['password']== md5(trim($password))){
					if(trim($repassword) == trim($newpassword)){
						$md5Pwd = md5(trim($newpassword));
						$sql = "update user set password='{$md5Pwd}',updatetime='{$updatetime}' where id={$userId}";
						//echo $sql;
						mysql_query($sql);
						// Check if the modification was successful
						if(mysql_affected_rows()>0){
							alertMes("Password reset successfully", "index.php");
						}else{
							echo "Password reset failed".mysql_error();
						}
					}else{
						alertMes("Passwords do not match", "updatePwd.php");
					}
				}else{
					alertMes("Incorrect old password", "updatePwd.php");
				}
			}else{
				alertMes('User does not exist', 'index.php');
			}

			
			break;
		
			
			

	}

// Close the database
mysql_close();


?>