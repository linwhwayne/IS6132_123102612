<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Online Shop</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css">
</head>

<body class="shop_body">
    <?php 
        // Include header
        include 'front-top.php';
    ?>
    <div class="shop_contain">
        <div style="height: 750px; display: flex;">
        <ul class="overflow_hidden">
        <?php 
            // Retrieve information from the database and output it to the browser in a table
            // 1. Import configuration file
            require_once "dbconfig.php";
                
            // Current page
            if(!isset($_GET["page"])){
                $page=1;
            }else{
                $page=$_GET["page"];
            }
                
            // Starting row of data
            $temp=($page-1)*$front_list_num;
                
            // Search keyword
            if(!isset($_GET['searchword'])){
                $searchword = "";
            }else{
                $searchword = trim($_GET['searchword']);
            }
                
                
            // 2. Operate the database
                
            $sql_count = "select count(*) as total from goods where 1";
            if($searchword){
                $sql_count.= " and name like '%{$searchword}%'";
            }
            $result = mysql_query($sql_count);
            if($result){
                $res = mysql_fetch_array($result);
                $num=$res['total'];
            }else{
                $num = 0;
            }
            
            $p_count=ceil($num/$front_list_num);               // Total number of pages
            
            // 3. Perform product information query
            $sql = "select * from goods where 1 ";
            if($searchword){
                $sql .=  " and name like '%{$searchword}%'";
            }
            $sql .= " limit {$temp},{$front_list_num}";
            $result = mysql_query($sql);
            // 4. Parse product information (parse result set)
            while($result && $row = mysql_fetch_assoc($result)){
        ?>
            <li>
                <div class="goods_item">
                    <div class="goods-div">
                    <a href="goodsDetail.php?id=<?php echo $row['id'];?>"><img  src="uploads/<?php echo $row['pic'];?>" class="goods_img"></a>
                    </div>
                    <div class="goods_price">￥<?php echo $row['price'];?></div>
                    <div class="goods_name"><?php echo $row['name'];?></div>
                </div>
            </li>
        <?php 
            }
        ?>
        
        </ul>
        </div>
        <div class="page_contain">
            <?php 
            // Pagination
            if($num > 0){
                $prev_page=$page-1;                     // Define previous page as current page minus 1
                $next_page=$page+1;                     // Define next page as current page plus 1
                echo "<p align=\"center\"> ";
                if ($page<=1)                           // If current page is less than or equal to 1, only display
                {
                    echo "First Page | ";
                }
                else                                    // If current page is greater than 1, display link to the first page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=1&searchword={$searchword}'>First Page</a> | ";
                }
                if ($prev_page<1)                       // If previous page is less than 1, only display text
                {
                    echo "Previous Page | ";
                }
                else                                    // If greater than 1, display link to the previous page
                {
                    echo "<a  href='".$_SERVER['PHP_SELF']."?page=$prev_page&searchword={$searchword}'>Previous Page</a> | ";
                }
                if ($next_page>$p_count)                // If next page is greater than total page count, only display text
                {
                    echo "Next Page | ";
                }
                else                                    // If less than total page count, display link to the next page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&searchword={$searchword}' >Next Page</a> | ";
                }
                if ($page>=$p_count)                    // If current page is greater than or equal to total page count, only display text
                {
                    echo "Last Page</p>\n";
                }
                else                                    // If current page is less than total page count, display link to the last page
                {
                    echo "<a href='".$_SERVER['PHP_SELF']."?page=$p_count&searchword={$searchword}'>Last Page</a></p>\n";
                }
            }else{
                echo "<P align='center'>No records found yet!</p>";
            }
            ?>
        </div>
    </div>
    <div class="bottom">
        <p style="text-align: center;height: 100px; line-height: 100px;">
            <a  href="index.php" style="color: #fff;">Home</a> <span>|</span> <a style="color: #fff;" href="myOrderList.php">My Orders </a>
        </p>
    </div>
</body>

</html>
```