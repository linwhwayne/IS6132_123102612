<!doctype html>
<html>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <title>Order Information Management</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
</head>
<body class="shop_body">
    <?php 
        include 'front-top.php';
        include 'functions.php';
        checkUserLogined(); // Check if the user is logged in
    ?>
    <h3>Order Information List</h3>
    <div class="admin_search_bar">
        <form action="<?php echo $_SERVER['PHP_SELF'];?>">
            <ul>
                <li><label>Product Name</label><input type="text" class="txt" name="keyword" autocomplete="off" value="<?php if(isset($_GET['keyword'])) echo $_GET['keyword'];?>"></li>
                <li><button class="op_btn">Search</button></li>
            </ul>
        </form>
    </div>
    <table border="1" style="width:100%;" class="frm_table">
        <tr>
            <th>Order Number</th>
            <th>Product Name</th>
            <th>Product Image</th>
            <th>Order Amount</th>
            <th>Shipping Address</th>
            <th>Order Time</th>
            <th>Operation</th>
        </tr>
        <?php
        
        
        // Retrieve information from the database and output it to the browser table
        // 1. Import configuration file
        require("dbconfig.php");
        
        // Current page
        if(!isset($_GET["page"])){
            $page=1;
        }else{
            $page=$_GET["page"];
        }
        
        // Starting row for data
        $temp=($page-1)*$front_list_num;
        
        // Search keyword
        if(!isset($_GET['keyword'])){
            $keyword = "";
        }else{
            $keyword = trim($_GET['keyword']);
        }
        
        
        // 2. Connect to the database
        $sql_count = "SELECT count(*) as total FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
        // Can only query own orders
        $sql_count .= " AND a.user_id=".$_SESSION['userId'];
        if($keyword){
            $sql_count.= " and c.`name` like '%{$keyword}%'";
        }
        $result = mysql_query($sql_count);
        if($result){
            $res = mysql_fetch_array($result);
            $num = $res['total'];
        }else{
            $num = 0;
        }
        
        $p_count=ceil($num/$front_list_num); // Total number of pages is total number of records divided by number of records per page
        
        // 3. Execute order information query
        $sql = "SELECT a.*,b.username,c.`name` as `goods_name`,c.pic FROM tb_order a, `user` b, goods c WHERE a.user_id=b.id AND a.goods_id=c.id ";
        // Can only query own orders
        $sql .= " AND a.user_id=".$_SESSION['userId'];
        
        if($keyword){
            $sql .=  " and c.`name` like '%{$keyword}%'";
        }
        $sql .= " limit {$temp},{$front_list_num}";
        $result = mysql_query($sql);
        
        
        
        // 4. Parse order information (parse result set)
        while($result && $row = mysql_fetch_assoc($result)){
            echo "<tr>";
            echo "<td width='40'>{$row['order_sn']}</td>";
            echo "<td width='100'>{$row['goods_name']}</td>";
            echo "<td width='60'><img src='./uploads/s_{$row['pic']}'/></td>";
            echo "<td width='60'>{$row['order_money']}</td>";
            echo "<td width='60'>{$row['consignee']}({$row['phone']},{$row['address']})</td>";
            echo "<td width='100'>".$row['createtime']."</td>";
            echo "<td width='60'> 
                    <a href='myOrderAction.php?action=del&id={$row['id']}' class='op_btn'>Delete</a>";
            echo "</tr>";
        }
        
        
        
        // 5. Free result set, close database
        ?>
    </table>
    <?php 
    // Pagination
    if($num > 0){
        $prev_page=$page-1; // Define the previous page as current page minus 1
        $next_page=$page+1; // Define the next page as current page plus 1
        echo "<p align=\"center\"> ";
        if ($page<=1) // If the current page is less than or equal to 1, only display
        {
            echo "First Page | ";
        }
        else // If the current page is greater than 1, display a link to the first page
        {
            echo "<a href='".$_SERVER['PHP_SELF']."?page=1&keyword={$keyword}'>First Page</a> | ";
        }
        if ($prev_page<1) // If the previous page is less than 1, only display text
        {
            echo "Previous Page | ";
        }
        else // If greater than 1, display a link to the previous page
        {
            echo "<a href='".$_SERVER['PHP_SELF']."?page=$prev_page&keyword={$keyword}'>Previous Page</a> | ";
        }
        if ($next_page>$p_count) // If the next page is greater than the total number of pages, only display text
        {
            echo "Next Page | ";
        }
        else // If less than the total number of pages, display a link to the next page
        {
            echo "<a href='".$_SERVER['PHP_SELF']."?page=$next_page&keyword={$keyword}' class='underline'>Next Page</a> | ";
        }
        if ($page>=$p_count) // If the current page is greater than or equal to the total number of pages, only display text
        {
            echo "Last Page</p>\n";
        }
        else // If the current page is less than the total number of pages, display a link to the last page
        {
            echo "<a href='".$_SERVER['PHP_SELF']."?page=$p_count&keyword={$keyword}'>Last Page</a></p>\n";
        }
    }else{
        echo "<P align='center'>No records yet!</p>";
    }
    ?>
    
</body>
</html>
