<?php
// Common configuration file
error_reporting(0); // Disable error reporting

// Database configuration
define("HOST", "localhost"); // Hostname
define("USER", "root");      // Username
define("PASS", "");          // Password
define("DBNAME", "123102612"); // Database name
define("COPYRIGHT", "All rights reserved");

$list_num = 5; // Number of rows to display in backend list
$front_list_num = 8; // Number of rows to display in frontend list

// Product type list information
$typelist = array(
    1 => "Fruit"
);

// If the mysql_pconnect function doesn't exist, define it using mysqli
if (!function_exists('mysql_pconnect')) {
    function mysql_pconnect($dbhost, $dbuser, $dbpass) {
        global $dbname;
        global $linkid;
        $linkid = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        return $linkid;
    }
    function mysql_select_db($dbname) {
        global $linkid;
        return mysqli_select_db($linkid, $dbname);
    }
    function mysql_fetch_array($result, $type = '') {
        if ($type) {
            return mysqli_fetch_array($result, $type);
        } else {
            return mysqli_fetch_array($result);
        }
    }
    function mysql_fetch_assoc($result) {
        return mysqli_fetch_assoc($result);
    }
    function mysql_fetch_row($result) {
        return mysqli_fetch_row($result);
    }
    function mysql_free_result($result) {
        return mysqli_free_result($result);
    }
    function mysql_query($cxn) {
        global $linkid;
        return mysqli_query($linkid, $cxn);
    }
    function mysql_insert_id() {
        global $linkid;
        return mysqli_insert_id($linkid);
    }
    function mysql_affected_rows() {
        global $linkid;
        return mysqli_affected_rows($linkid);
    }
    function mysql_escape_string($data) {
        global $linkid;
        return mysqli_real_escape_string($linkid, $data);
    }
    function mysql_real_escape_string($data) {
        global $linkid;
        return mysqli_real_escape_string($linkid, $data);
    }
    function mysql_close() {
        global $linkid;
        return mysqli_close($linkid);
    }
    function mysql_get_server_info() {
        global $linkid;
        return mysqli_get_server_info($linkid);
    }
    function mysql_num_rows($result) {
        return mysqli_num_rows($result);
    }
}

// Set appropriate error reporting based on PHP version and environment needs
error_reporting(E_ERROR | E_PARSE);           // Report simple running errors
error_reporting(E_ALL ^ E_WARNING);           // Report all errors except E_WARNING
error_reporting(E_ALL & ~E_NOTICE);           // Report all errors except E_NOTICE
error_reporting(E_ALL ^ E_DEPRECATED);        // Report all errors except deprecated ones

// Compatibility with different PHP versions
if (version_compare(PHP_VERSION, '7.0.0', '<')) {
    mysql_connect(HOST, USER, PASS) or die("DB connect error" . mysql_error());
} else {
    mysql_pconnect(HOST, USER, PASS) or die("DB connect error" . mysql_error());
}

mysql_select_db(DBNAME); // Select database
mysql_query("SET NAMES utf8"); // Set database encoding
?>
