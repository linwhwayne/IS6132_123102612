<?php 
session_start(); // Start session
require("functions.php"); // Include functions
checkLogined(); // Check if the admin is logged in
?>
<!doctype html>
<html>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
        <title>Backend Management</title>
        <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    </head>
    <body>
        <div class="admin_head">
            <h3>Backend Management System</h3>
        </div>
        <div class="admin_content">
            <!-- Left Sidebar -->
            <div class="menu">
                <div class="cont">
                    <div class="title">Administrator</div>
                    <ul class="mList">
                        <li>
                            <h3><span>+</span>User Management</h3>
                            <dl>
                                <dd><a class='pageA' href="admin_user/addUser.php" target="mainFrame">Add User</a></dd>
                                <dd><a class='pageA' href="admin_user/userList.php" target="mainFrame">User List</a></dd>
                            </dl>
                        </li>
                        <li>
                            <h3><span>+</span>Product Management</h3>
                            <dl>
                                <dd><a class='pageA' href="admin_goods/addGoods.php" target="mainFrame">Add Product</a></dd>
                                <dd><a class='pageA' href="admin_goods/goodsList.php" target="mainFrame">Product List</a></dd>
                            </dl>
                        </li>
                        <li>
                            <h3><span>+</span>Order Management</h3>
                            <dl>
                                <dd><a class='pageA' href="admin_order/orderList.php" target="mainFrame">Order List</a></dd>
                            </dl>
                        </li>
                        <li>
                            <h3><span>+</span>System Management</h3>
                            <dl>
                                <dd><a class='pageA' href="index.php">Return to Homepage</a></dd>
                            </dl>
                            <dl>
                                <dd><a class='pageA' href="loginAction.php?act=logout">Logout</a></dd>
                            </dl>
                        </li>
                    </ul>
                </div>
            </div>
        
            <div class="main">
                <!-- Right Content -->
                <div class="cont">
                    <!-- Nested webpage start -->         
                    <iframe src="adminMain.php" frameborder="0" name="mainFrame" width="100%" height="800"></iframe>
                    <!-- Nested webpage end -->   
                </div>
            </div>
            
        </div>
        
    </body>
</html>
